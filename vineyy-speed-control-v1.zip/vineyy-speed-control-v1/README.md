# Vineyy – Speed Control

Chrome-utvidelse (Manifest V3) for hastighet og pitch på HTML5-video og -lyd. Laget for YouTube, YouTube Music og Spotify, men virker på alle nettsider med media.

## Installasjon (testing)
1. Pakk ut zip-filen til en mappe.
2. Åpne `chrome://extensions` og slå på **Developer mode**.
3. **Load unpacked** → velg mappen.
4. Etter oppdatering: trykk reload-ikonet på utvidelsen. Faner som allerede er åpne (f.eks. YouTube Music) trenger ikke refresh.

## Bruk
- **Speed / Pitch:** 0.25x – 2x. Klikk på tallet for å skrive inn eksakt verdi (`0.85` eller `0,85`).
- **Link Speed & Pitch:** på = pitch følger speed (som vinyl/kassett, ingen lydbehandling, ingen robotlyd). Av = uavhengig pitch.
- **Reset-ikon:** tilbake til 1x (ved link nullstilles begge).
- **Presets:** klikk = sett speed og pitch. Hold inne (0,6 s) eller høyreklikk = lagre nåværende speed i knappen.
- **Pille øverst:** «No media» vises kun når fanen ikke har lyd/video. «Pitch limited on this site» vises på beskyttet lyd (Spotify) når pitch er ulinket.
- Innstillingene gjelder kun fanen du endret dem i, beholdes ved refresh, og nye faner starter på 1x.

## Font (Inter)
Legg `InterVariable.woff2` fra https://rsms.me/inter/ i mappen `fonts/` (se `fonts/README.txt`). Uten filen brukes lokalt installert Inter, ellers systemfonten.

## Struktur
```
manifest.json
background/service-worker.js   Tilstand per fane og mediestatus (chrome.storage.session), badge
content/content.js             Inngangspunkt i hver side/frame
content/media-controller.js    Finner video/audio (også i shadow DOM), setter hastighet og holder den
content/pitch-engine.js        Web Audio-kobling for uavhengig pitch
content/pitch-worklet.js       AudioWorklet (pitch shifter) + pitch-core.js (felles DSP)
popup/                         UI (html, css, js)
shared/constants.js            Konstanter og hjelpefunksjoner
fonts/ icons/                  Font og ikoner
```
