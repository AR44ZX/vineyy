/**
 * Popup controller.
 *
 * - Speed / pitch / link state is per tab and stored by the background worker,
 *   so reopening the popup never resets anything.
 * - Presets are global (chrome.storage.sync).
 *     click              → apply preset to speed AND pitch
 *     hold / right-click → save the current speed into that preset
 * - The popup knows whether the tab has audio/video (reported by the content
 *   scripts). When there is none, a small "No media" pill fades in – the
 *   controls always stay usable.
 * - On protected audio (e.g. Spotify) the browser blocks independent pitch.
 *   Pitch can then only follow speed or stay at 1x, and a pill says so.
 */
(() => {
  'use strict';

  const {
    MSG, DEFAULT_PRESETS, DEFAULT_STATE, EMPTY_MEDIA_STATUS, SLIDER_MAX, MIN, MAX,
    valueToSlider, sliderToValue, normalize, formatValue, formatPlain, parseValue,
    sanitizeState, sanitizePresets,
  } = VINEYY;

  const LONG_PRESS_MS = 600;
  const TWEEN_MS = 320;
  const PRESETS_KEY = 'presets';
  const REDUCED_MOTION = matchMedia('(prefers-reduced-motion: reduce)').matches;

  const $ = (id) => document.getElementById(id);
  const controls = {
    speed: { slider: $('speed-slider'), input: $('speed-value'), reset: $('speed-reset') },
    pitch: { slider: $('pitch-slider'), input: $('pitch-value'), reset: $('pitch-reset') },
  };
  const linkToggle = $('link-toggle');
  const presetButtons = [...document.querySelectorAll('.preset')];
  const statusEl = $('status');

  let tabId = null;
  let state = { ...DEFAULT_STATE };
  let presets = [...DEFAULT_PRESETS];

  /* ---------- State changes ---------- */

  // Slider drags fire ~60 events/s; coalesce them so the page isn't flooded with messages.
  const SEND_INTERVAL_MS = 40;
  let sendTimer = null;
  let dirty = false;

  function flushSend() {
    clearTimeout(sendTimer);
    sendTimer = null;
    if (!dirty || tabId === null) return;
    dirty = false;
    chrome.runtime.sendMessage({ type: MSG.SET_TAB_STATE, tabId, state }).catch(() => {});
  }

  function commit(next, animate = false) {
    state = sanitizeState(next);
    render(animate);
    dirty = true;
    if (!sendTimer) sendTimer = setTimeout(flushSend, SEND_INTERVAL_MS);
  }

  // The popup can close right after a change – never lose the last value.
  ['pointerup', 'keyup', 'pagehide'].forEach((type) => addEventListener(type, flushSend));

  const setSpeed = (value, animate = false) => {
    const v = normalize(value);
    commit({ ...state, speed: v, pitch: state.linked ? v : state.pitch }, animate);
  };
  const setPitch = (value, animate = false) => {
    if (!state.linked) commit({ ...state, pitch: normalize(value) }, animate);
  };
  const setLinked = (linked) => {
    commit({ ...state, linked, pitch: linked ? state.speed : state.pitch }, true);
  };
  const setBoth = (value) => {
    const v = normalize(value);
    commit({ ...state, speed: v, pitch: v }, true);
  };

  /* ---------- Rendering (with a visual tween for non-drag changes) ---------- */

  const shown = { speed: null, pitch: null }; // value currently on screen (may be mid-tween)
  const frames = {};

  function paint(name, value) {
    const { slider, input } = controls[name];
    const position = valueToSlider(value);
    slider.value = position;
    slider.style.setProperty('--p', position / SLIDER_MAX);
    if (document.activeElement !== input) input.value = formatValue(value);
  }

  function renderControl(name, value, locked, animate) {
    const { slider, input } = controls[name];
    slider.disabled = locked;
    input.disabled = locked;

    cancelAnimationFrame(frames[name]);
    const from = shown[name];

    if (!animate || REDUCED_MOTION || from === null || Math.abs(from - value) < 0.005) {
      paint(name, value);
      shown[name] = value;
      return;
    }

    const start = performance.now();
    const step = (now) => {
      const t = Math.min(1, (now - start) / TWEEN_MS);
      const eased = 1 - Math.pow(1 - t, 3);
      const current = t < 1 ? from + (value - from) * eased : value;
      paint(name, current);
      shown[name] = current;
      if (t < 1) frames[name] = requestAnimationFrame(step);
    };
    frames[name] = requestAnimationFrame(step);
  }

  function render(animate = false) {
    renderControl('speed', state.speed, false, animate);
    renderControl('pitch', state.pitch, state.linked, animate);
    linkToggle.setAttribute('aria-checked', String(state.linked));
    renderMedia();
    presetButtons.forEach((button, i) => {
      if (!button.classList.contains('preset--saved')) button.textContent = formatValue(presets[i]);
    });
  }

  /* ---------- Media status ---------- */

  const NO_MEDIA_DELAY_MS = 700; // ignore short gaps (e.g. between two tracks)
  const STATUS_TEXT = { 'no-media': 'No media', limited: 'Pitch limited on this site' };
  const statusText = $('status-text');
  let media = null;          // null = unknown (never claim "No media" without a confirmed answer)
  let noMediaTimer = null;
  let statusKind = null;

  function showStatus(kind) {
    if (kind === statusKind) return;
    statusKind = kind;
    if (kind) {
      statusText.textContent = STATUS_TEXT[kind];
      statusEl.dataset.kind = kind;
    }
    statusEl.classList.toggle('is-visible', Boolean(kind));
    statusEl.setAttribute('aria-hidden', String(!kind));
  }

  function renderMedia() {
    clearTimeout(noMediaTimer);
    if (!media) return showStatus(null);
    if (!media.hasMedia) {
      noMediaTimer = setTimeout(() => showStatus('no-media'), NO_MEDIA_DELAY_MS);
      return;
    }
    showStatus(media.limited && !state.linked ? 'limited' : null);
  }

  function setMedia(status) {
    media = { ...EMPTY_MEDIA_STATUS, ...status };
    renderMedia();
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === MSG.MEDIA_STATUS_CHANGED && message.tabId === tabId) setMedia(message.status);
  });

  /** Tabs opened before the extension was installed have no content script yet. */
  async function ensureContentScript(id) {
    try {
      const reply = await chrome.tabs.sendMessage(id, { type: MSG.PING });
      if (reply?.ok) return;
    } catch { /* not injected */ }
    try {
      const files = chrome.runtime.getManifest().content_scripts[0].js;
      await chrome.scripting.executeScript({ target: { tabId: id, allFrames: true }, files });
    } catch { /* restricted page (chrome://, Web Store, …) */ }
  }

  /* ---------- Slider, value input, reset ---------- */

  const KEY_STEPS = {
    ArrowLeft: -0.01, ArrowDown: -0.01, ArrowRight: 0.01, ArrowUp: 0.01,
    PageDown: -0.1, PageUp: 0.1,
  };
  const currentValue = (name) => (name === 'speed' ? state.speed : state.pitch);

  function spin(button) {
    button.classList.remove('is-spinning');
    void button.offsetWidth; // restart the animation
    button.classList.add('is-spinning');
  }

  function bindControl(name, setValue, resetValue) {
    const { slider, input, reset } = controls[name];

    slider.addEventListener('input', () => setValue(sliderToValue(slider.value)));

    // Native arrow keys move 1/1000 of the range, which rounds to nothing – use 0.01 steps instead.
    slider.addEventListener('keydown', (event) => {
      let next = null;
      if (event.key in KEY_STEPS) next = currentValue(name) + KEY_STEPS[event.key];
      else if (event.key === 'Home') next = MIN;
      else if (event.key === 'End') next = MAX;
      if (next === null) return;
      event.preventDefault();
      setValue(next);
    });

    input.addEventListener('focus', () => {
      input.value = formatPlain(currentValue(name));
      input.select();
    });
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') input.blur();
      if (event.key === 'Escape') { input.dataset.cancel = '1'; input.blur(); }
    });
    input.addEventListener('blur', () => {
      const parsed = input.dataset.cancel ? null : parseValue(input.value);
      delete input.dataset.cancel;
      if (parsed !== null) setValue(parsed, true);
      input.value = formatValue(currentValue(name));
      render();
    });

    reset.addEventListener('click', () => { spin(reset); resetValue(); });
    reset.addEventListener('animationend', () => reset.classList.remove('is-spinning'), true);
  }

  bindControl('speed', setSpeed, () => setSpeed(1, true));
  // While linked, resetting either control resets both.
  bindControl('pitch', setPitch, () => (state.linked ? setSpeed(1, true) : setPitch(1, true)));

  linkToggle.addEventListener('click', () => setLinked(!state.linked));

  /* ---------- Presets ---------- */

  function flash(button, className) {
    button.classList.remove(className);
    void button.offsetWidth;
    button.classList.add(className);
  }

  function savePreset(index) {
    presets[index] = normalize(state.speed);
    chrome.storage.sync.set({ [PRESETS_KEY]: presets }).catch(() => {});

    const button = presetButtons[index];
    button.textContent = 'Saved';
    flash(button, 'preset--saved');
    setTimeout(() => {
      button.classList.remove('preset--saved');
      render();
    }, 700);
  }

  presetButtons.forEach((button, index) => {
    let timer = null;
    let longPressed = false;
    const cancel = () => clearTimeout(timer);

    button.title = 'Click: apply · Hold or right-click: save current speed';

    button.addEventListener('pointerdown', (event) => {
      if (event.button !== 0) return;
      longPressed = false;
      timer = setTimeout(() => { longPressed = true; savePreset(index); }, LONG_PRESS_MS);
    });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach((type) => button.addEventListener(type, cancel));

    button.addEventListener('click', () => {
      if (longPressed) { longPressed = false; return; }
      flash(button, 'preset--pulse');
      setBoth(presets[index]);
    });
    button.addEventListener('animationend', () => button.classList.remove('preset--pulse'));
    button.addEventListener('contextmenu', (event) => {
      event.preventDefault();
      savePreset(index);
    });
  });

  /* ---------- Init ---------- */

  async function init() {
    render(); // neutral first paint (hidden by the entrance animation)

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id ?? null;
    if (tabId !== null) await ensureContentScript(tabId);

    const ask = (type) => (tabId !== null
      ? chrome.runtime.sendMessage({ type, tabId }).catch(() => null)
      : Promise.resolve(null));

    const [stateResponse, mediaResponse, stored] = await Promise.all([
      ask(MSG.GET_TAB_STATE),
      ask(MSG.GET_MEDIA_STATUS),
      chrome.storage.sync.get(PRESETS_KEY).catch(() => ({})),
    ]);

    if (stateResponse?.ok) state = sanitizeState(stateResponse.state);
    presets = sanitizePresets(stored[PRESETS_KEY]);
    render(true); // sliders glide from neutral to the saved values
    if (mediaResponse?.ok) setMedia(mediaResponse.status);
  }

  init();
})();
