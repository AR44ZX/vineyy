/**
 * Shared constants and pure helpers.
 * Loaded as a classic script by the content scripts, the popup and the
 * service worker (via importScripts), and exposed as `VINEYY`.
 */
(function (root) {
  'use strict';

  const MIN = 0.25;
  const MAX = 2;

  // The slider is piecewise-linear so that 1.0x always sits in the centre:
  //   position   0 → 0.25x,   500 → 1.0x,   1000 → 2.0x
  const SLIDER_MAX = 1000;
  const SLIDER_MID = SLIDER_MAX / 2;

  const MSG = Object.freeze({
    GET_TAB_STATE: 'vineyy/get-tab-state',
    SET_TAB_STATE: 'vineyy/set-tab-state',
    APPLY_STATE: 'vineyy/apply-state',
    PING: 'vineyy/ping',
    REPORT_MEDIA: 'vineyy/report-media',
    GET_MEDIA_STATUS: 'vineyy/get-media-status',
    MEDIA_STATUS_CHANGED: 'vineyy/media-status-changed',
  });

  const EMPTY_MEDIA_STATUS = Object.freeze({ hasMedia: false, playing: false, limited: false });

  const DEFAULT_STATE = Object.freeze({ speed: 1, pitch: 1, linked: true });
  const DEFAULT_PRESETS = Object.freeze([0.85, 0.9, 1.25]);

  const round2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, lo = MIN, hi = MAX) => Math.min(hi, Math.max(lo, v));

  /** Coerces anything into a valid multiplier in [MIN, MAX], rounded to 0.01. */
  function normalize(value) {
    const n = Number(value);
    return Number.isFinite(n) ? round2(clamp(n)) : 1;
  }

  function valueToSlider(value) {
    const v = normalize(value);
    const pos = v <= 1
      ? ((v - MIN) / (1 - MIN)) * SLIDER_MID
      : SLIDER_MID + ((v - 1) / (MAX - 1)) * (SLIDER_MAX - SLIDER_MID);
    return Math.round(pos);
  }

  function sliderToValue(pos) {
    const p = clamp(Number(pos), 0, SLIDER_MAX);
    const v = p <= SLIDER_MID
      ? MIN + (p / SLIDER_MID) * (1 - MIN)
      : 1 + ((p - SLIDER_MID) / (SLIDER_MAX - SLIDER_MID)) * (MAX - 1);
    return normalize(v);
  }

  /** 0.85 → "0.85" (no unit, used while typing a value) */
  function formatPlain(value) {
    return String(normalize(value));
  }

  /** 1 → "1.0x", 0.9 → "0.9x", 0.85 → "0.85x" */
  function formatValue(value) {
    const v = normalize(value);
    return (Number.isInteger(v) ? v.toFixed(1) : String(v)) + 'x';
  }

  /** Parses user input such as "0,85", "0.85x" or " 1.25 X". Returns null if invalid. */
  function parseValue(text) {
    const cleaned = String(text).trim().replace(',', '.').replace(/x$/i, '').trim();
    if (cleaned === '') return null;
    const n = Number(cleaned);
    return Number.isFinite(n) ? normalize(n) : null;
  }

  function sanitizeState(raw) {
    const src = raw && typeof raw === 'object' ? raw : {};
    const linked = typeof src.linked === 'boolean' ? src.linked : DEFAULT_STATE.linked;
    const speed = normalize(src.speed ?? DEFAULT_STATE.speed);
    const pitch = linked ? speed : normalize(src.pitch ?? DEFAULT_STATE.pitch);
    return { speed, pitch, linked };
  }

  function sanitizePresets(raw) {
    const list = Array.isArray(raw) ? raw : [];
    return DEFAULT_PRESETS.map((fallback, i) => (i in list ? normalize(list[i]) : fallback));
  }

  const isDefaultState = (s) => s.speed === 1 && s.pitch === 1;

  root.VINEYY = Object.freeze({
    MIN, MAX, SLIDER_MAX, MSG, DEFAULT_STATE, DEFAULT_PRESETS, EMPTY_MEDIA_STATUS,
    clamp, normalize, valueToSlider, sliderToValue,
    formatValue, formatPlain, parseValue, sanitizeState, sanitizePresets, isDefaultState,
  });
})(globalThis);
