Place InterVariable.woff2 in this folder.

Inter is licensed under the SIL Open Font License 1.1, so it may be bundled and
redistributed (also in a Chrome Web Store package). Download from https://rsms.me/inter/
("Inter Variable" web font), and keep the license text next to the font as OFL.txt.

If the file is missing, the popup uses a locally installed Inter, then the system font.
