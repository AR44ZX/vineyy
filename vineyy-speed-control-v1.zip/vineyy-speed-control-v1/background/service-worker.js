/**
 * Background service worker.
 *
 * Owns two pieces of per-tab data, both in chrome.storage.session (keyed by
 * tab id), so they survive refreshes and worker restarts but never leak
 * between tabs, and disappear when the tab closes:
 *   - the user's state (speed / pitch / link)
 *   - the media status reported by the content scripts of every frame
 *     (is there audio/video, is it playing, can pitch be set independently)
 */
importScripts('../shared/constants.js');

const { MSG, EMPTY_MEDIA_STATUS, sanitizeState, isDefaultState } = VINEYY;

const stateKey = (tabId) => `tab:${tabId}`;
const mediaKey = (tabId) => `media:${tabId}`;

/* Serialises read-modify-write cycles so frames can't overwrite each other. */
let queue = Promise.resolve();
const enqueue = (task) => (queue = queue.then(task, task));

async function getState(tabId) {
  const stored = await chrome.storage.session.get(stateKey(tabId));
  return sanitizeState(stored[stateKey(tabId)]);
}

async function setState(tabId, raw) {
  const state = sanitizeState(raw);
  await chrome.storage.session.set({ [stateKey(tabId)]: state });
  return state;
}

function aggregate(frames) {
  const list = Object.values(frames || {});
  return {
    hasMedia: list.length > 0,
    playing: list.some((f) => f.playing),
    limited: list.some((f) => f.limited),
  };
}

async function getMediaStatus(tabId) {
  const stored = await chrome.storage.session.get(mediaKey(tabId));
  return aggregate(stored[mediaKey(tabId)]);
}

function reportFrameStatus(tabId, frameId, status) {
  return enqueue(async () => {
    const key = mediaKey(tabId);
    const frames = (await chrome.storage.session.get(key))[key] || {};
    if (status?.hasMedia) frames[frameId] = status;
    else delete frames[frameId];

    if (Object.keys(frames).length) await chrome.storage.session.set({ [key]: frames });
    else await chrome.storage.session.remove(key);
    return aggregate(frames);
  });
}

/** Toolbar badge: active speed, only when there really is media on the page. */
async function updateBadge(tabId) {
  const [state, media] = await Promise.all([getState(tabId), getMediaStatus(tabId)]);
  let text = '';
  if (media.hasMedia && !isDefaultState(state)) {
    text = state.speed !== 1 ? String(state.speed) : 'P';
  }
  try {
    await chrome.action.setBadgeText({ tabId, text });
  } catch {
    /* Tab no longer exists. */
  }
}

/** Pushes the state to every frame of the tab. */
async function broadcast(tabId, state) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: MSG.APPLY_STATE, state });
  } catch {
    /* No content script (e.g. chrome:// pages). */
  }
}

async function handleMessage(message, sender) {
  // The popup passes its target tab explicitly; content scripts are identified by sender.tab.
  const tabId = message.tabId ?? sender.tab?.id;
  if (typeof tabId !== 'number') return { ok: false };

  switch (message.type) {
    case MSG.GET_TAB_STATE: {
      const state = await getState(tabId);
      updateBadge(tabId); // Chrome resets badges on navigation – restore it.
      return { ok: true, state };
    }
    case MSG.SET_TAB_STATE: {
      const state = await setState(tabId, message.state);
      updateBadge(tabId);
      broadcast(tabId, state);
      return { ok: true, state };
    }
    case MSG.REPORT_MEDIA: {
      const status = await reportFrameStatus(tabId, sender.frameId ?? 0, message.status);
      updateBadge(tabId);
      chrome.runtime.sendMessage({ type: MSG.MEDIA_STATUS_CHANGED, tabId, status }).catch(() => {});
      return { ok: true };
    }
    case MSG.GET_MEDIA_STATUS:
      return { ok: true, status: await getMediaStatus(tabId) };
    default:
      return { ok: false };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !Object.values(MSG).includes(message.type) || message.type === MSG.MEDIA_STATUS_CHANGED) return;
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((error) => {
      console.error('[Vineyy]', error);
      sendResponse({ ok: false });
    });
  return true; // keep the channel open for the async response
});

chrome.tabs.onRemoved.addListener((tabId) => {
  enqueue(() => chrome.storage.session.remove([stateKey(tabId), mediaKey(tabId)]));
});

/* Badge colours are global, so set them once per worker start instead of on every update. */
chrome.action.setBadgeBackgroundColor({ color: '#3d88ff' });
if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: '#ffffff' });

/**
 * Content scripts are only injected into pages opened AFTER the extension was
 * installed/updated. Inject into tabs that are already open (e.g. a playing
 * YouTube Music tab) so the user does not have to refresh them.
 */
async function injectIntoOpenTabs() {
  const files = chrome.runtime.getManifest().content_scripts[0].js;
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  await Promise.all(tabs.map((tab) =>
    chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files }).catch(() => {})));
}

chrome.runtime.onInstalled.addListener(() => { injectIntoOpenTabs(); });
