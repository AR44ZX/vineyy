/**
 * MediaController – applies speed and pitch to every <video>/<audio> element
 * in the current frame, keeps them applied when the page fights back
 * (YouTube resets playbackRate on track changes, ads, etc.), and reports
 * whether this frame has media / is playing / can set pitch independently.
 *
 * Strategy:
 *  - Native: playbackRate = speed with preservesPitch = false. The browser
 *    then resamples like a tape/vinyl, so the pitch follows the speed
 *    exactly, with no DSP and therefore no robotic artefacts.
 *  - Independent pitch: whatever is left over (pitch / speed) is applied by
 *    the pitch shifter in PitchEngine. When linked, that remainder is exactly 1.
 *  - Protected / cross-origin media (e.g. Spotify) cannot be routed through
 *    Web Audio. There the browser's own time-stretching is used instead, which
 *    gives exactly two pitch options: "follows speed" or "stays at 1x".
 */
(function (root) {
  'use strict';

  const MEDIA_EVENTS = [
    'loadstart', 'loadedmetadata', 'loadeddata', 'play', 'playing',
    'pause', 'ended', 'emptied', 'ratechange', 'volumechange',
  ];
  const SCAN_DEBOUNCE_MS = 200;
  const REPORT_DEBOUNCE_MS = 150;
  const MAX_WRITES_PER_SECOND = 30;

  // Media inside open shadow roots (e.g. Reddit) is invisible to querySelectorAll,
  // so those are searched on a slow timer that backs off if the page is huge.
  const SHADOW_SCAN_MS = 2000;
  const SHADOW_SCAN_SLOW_MS = 10000;
  const SHADOW_SCAN_BUDGET_MS = 20;

  function setPreservesPitch(media, value) {
    if (media.preservesPitch !== value) media.preservesPitch = value;
    if ('webkitPreservesPitch' in media && media.webkitPreservesPitch !== value) {
      media.webkitPreservesPitch = value;
    }
  }

  const hasSource = (media) => Boolean(media.currentSrc || media.srcObject);

  class MediaController {
    /** @param {{ engine?: object }} [options] reuse an existing engine when a script is re-injected */
    constructor({ engine } = {}) {
      this.state = { ...VINEYY.DEFAULT_STATE };
      this.active = false;
      this.media = new Set();
      this.writes = new WeakMap();
      this.scanTimer = null;
      this.reportTimer = null;
      this.shadowTimer = null;
      this.lastReport = null;
      this.engine = engine || new VineyyPitchEngine({ onUnlock: () => {} });
      this.engine.onUnlock = () => this.applyAll();
      this.handleMediaEvent = (event) => {
        this.apply(event.currentTarget);
        this.scheduleReport();
      };
      this.handlePageHide = () => this.report(true, VINEYY.EMPTY_MEDIA_STATUS);
      this.handlePageShow = (event) => { if (event.persisted) this.report(true); }; // back/forward cache
    }

    start() {
      this.scan();
      this.report(true); // always announce this frame, which also clears stale data after a refresh
      this.observer = new MutationObserver(() => this.scheduleScan());
      this.observer.observe(document, { childList: true, subtree: true });
      document.addEventListener('DOMContentLoaded', () => this.scan(), { once: true });
      window.addEventListener('pagehide', this.handlePageHide);
      window.addEventListener('pageshow', this.handlePageShow);
      this.scheduleShadowScan(SHADOW_SCAN_MS);
    }

    /** Receives the authoritative state for this tab. */
    setState(raw) {
      this.state = VINEYY.sanitizeState(raw);
      const wasActive = this.active;
      this.active = !VINEYY.isDefaultState(this.state);

      if (this.active) this.applyAll();
      else if (wasActive) this.restoreAll();
    }

    /* ---------- Discovery ---------- */

    scheduleScan() {
      if (this.scanTimer) return;
      this.scanTimer = setTimeout(() => {
        this.scanTimer = null;
        this.scan();
      }, SCAN_DEBOUNCE_MS);
    }

    scan() {
      let changed = false;
      for (const media of this.media) {
        if (!media.isConnected) { this.untrack(media); changed = true; }
      }
      document.querySelectorAll('video, audio').forEach((media) => {
        if (!this.media.has(media)) { this.track(media); changed = true; }
      });
      if (changed) this.scheduleReport();
    }

    scheduleShadowScan(delay) {
      this.shadowTimer = setTimeout(() => {
        const started = performance.now();
        this.scanShadowRoots();
        const slow = performance.now() - started > SHADOW_SCAN_BUDGET_MS;
        this.scheduleShadowScan(slow ? SHADOW_SCAN_SLOW_MS : SHADOW_SCAN_MS);
      }, delay);
    }

    scanShadowRoots() {
      if (!this.isContextValid()) return this.destroy();
      let changed = false;
      const visit = (root) => {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
        for (let node = walker.nextNode(); node; node = walker.nextNode()) {
          const shadow = node.shadowRoot;
          if (!shadow) continue;
          shadow.querySelectorAll('video, audio').forEach((media) => {
            if (!this.media.has(media)) { this.track(media); changed = true; }
          });
          visit(shadow);
        }
      };
      visit(document);
      if (changed) this.scheduleReport();
    }

    track(media) {
      this.media.add(media);
      MEDIA_EVENTS.forEach((type) => media.addEventListener(type, this.handleMediaEvent));
      this.apply(media);
    }

    untrack(media) {
      this.media.delete(media);
      MEDIA_EVENTS.forEach((type) => media.removeEventListener(type, this.handleMediaEvent));
    }

    /* ---------- Status reporting ---------- */

    getStatus() {
      const withSource = [...this.media].filter(hasSource);
      return {
        hasMedia: withSource.length > 0,
        playing: withSource.some((m) => !m.paused && !m.ended && m.readyState >= 2),
        limited: withSource.some((m) => !this.engine.canRoute(m)),
      };
    }

    scheduleReport() {
      if (this.reportTimer) return;
      this.reportTimer = setTimeout(() => {
        this.reportTimer = null;
        this.report();
      }, REPORT_DEBOUNCE_MS);
    }

    report(force = false, status = this.getStatus()) {
      const serialized = JSON.stringify(status);
      if (!force && serialized === this.lastReport) return;
      this.lastReport = serialized;
      try {
        chrome.runtime.sendMessage({ type: VINEYY.MSG.REPORT_MEDIA, status }).catch(() => {});
      } catch {
        /* Extension context invalidated (extension was reloaded). */
      }
    }

    /* ---------- Applying speed and pitch ---------- */

    applyAll() {
      this.media.forEach((media) => this.apply(media));
    }

    apply(media) {
      if (!this.isContextValid()) return this.destroy();
      if (!this.active) return;
      const { speed, pitch } = this.state;

      if (this.engine.canRoute(media)) {
        // Native resampling makes pitch follow speed; the engine corrects the remainder.
        setPreservesPitch(media, false);
        this.engine.update(media, pitch / speed);
      } else {
        // No Web Audio possible: pick the closer of "pitch = speed" and "pitch = 1".
        setPreservesPitch(media, Math.abs(pitch - 1) < Math.abs(pitch - speed));
      }

      if (Math.abs(media.playbackRate - speed) > 1e-4 && this.canWrite(media)) {
        media.playbackRate = speed;
      }
    }

    /** After an extension reload/update the old content script is orphaned. */
    isContextValid() {
      return Boolean(globalThis.chrome?.runtime?.id);
    }

    /** Stops all listeners and timers. Media that was routed through Web Audio stays routed (engine is reusable). */
    destroy() {
      this.active = false;
      this.observer?.disconnect();
      clearTimeout(this.scanTimer);
      clearTimeout(this.reportTimer);
      clearTimeout(this.shadowTimer);
      window.removeEventListener('pagehide', this.handlePageHide);
      window.removeEventListener('pageshow', this.handlePageShow);
      [...this.media].forEach((media) => this.untrack(media));
    }

    restoreAll() {
      this.media.forEach((media) => {
        media.playbackRate = 1;
        setPreservesPitch(media, true);
        this.engine.update(media, 1);
      });
    }

    /** Safety valve in case a page keeps overwriting playbackRate in a loop. */
    canWrite(media) {
      const now = performance.now();
      let record = this.writes.get(media);
      if (!record || now - record.start > 1000) record = { start: now, count: 0 };
      record.count += 1;
      this.writes.set(media, record);
      return record.count <= MAX_WRITES_PER_SECOND;
    }
  }

  root.VineyyMediaController = MediaController;
})(globalThis);
