/**
 * AudioWorklet wrapper around PitchShifterCore.
 * Loaded as an ES module by PitchEngine (see pitch-engine.js).
 */
import { PitchShifterCore } from './pitch-core.js';

class VineyyPitchShifter extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [{ name: 'ratio', defaultValue: 1, minValue: 0.05, maxValue: 16, automationRate: 'k-rate' }];
  }

  constructor() {
    super();
    this.core = new PitchShifterCore(sampleRate);
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    const output = outputs[0];
    if (input && input.length > 0) this.core.process(input, output, parameters.ratio[0]);
    return true;
  }
}

registerProcessor('vineyy-pitch-shifter', VineyyPitchShifter);
