/**
 * PitchEngine – routes media elements through the pitch shifter.
 *
 * One shared AudioContext per frame. A media element is only routed through
 * Web Audio when it actually needs independent pitch (ratio ≠ 1), because
 * createMediaElementSource() is irreversible and outputs silence for
 * cross-origin media without CORS and for DRM (EME) streams. Linked
 * speed/pitch never needs this.
 *
 * Two back-ends share the same DSP core:
 *   1. AudioWorklet (preferred, runs off the main thread)
 *   2. ScriptProcessorNode (fallback for pages whose CSP blocks the worklet)
 */
(function (root) {
  'use strict';

  const PROCESSOR_NAME = 'vineyy-pitch-shifter';
  const WORKLET_PATH = 'content/pitch-worklet.js';
  const CORE_PATH = 'content/pitch-core.js';
  const UNLOCK_EVENTS = ['pointerdown', 'keydown', 'touchstart'];
  const BYPASS_EPSILON = 0.002;

  // Services that always use DRM (EME). Web Audio would silence them, so they are never routed.
  const DRM_HOSTS = /(^|\.)(spotify\.com|netflix\.com|disneyplus\.com|primevideo\.com|hulu\.com|hbomax\.com|max\.com|tv\.apple\.com|music\.apple\.com)$/i;

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  class PitchEngine {
    /** @param {{ onUnlock: () => void }} options */
    constructor({ onUnlock }) {
      this.onUnlock = onUnlock;
      this.context = null;
      this.backend = null; // 'worklet' | 'script'
      this.backendReady = null;
      this.PitchShifterCore = null;
      this.failed = false;
      this.nodes = new WeakMap(); // media → { setRatio(r) }
      this.pending = new WeakMap();
      this.desired = new WeakMap();
      this.unlockArmed = false;
    }

    /** Sets the extra pitch ratio for a media element (1 = untouched). */
    update(media, ratio) {
      this.desired.set(media, ratio);

      const node = this.nodes.get(media);
      if (node) {
        node.setRatio(ratio);
        return;
      }
      if (Math.abs(ratio - 1) < BYPASS_EPSILON || media.muted || !this.canRoute(media)) return;

      this.attach(media).then((attached) => {
        if (attached) attached.setRatio(this.desired.get(media) ?? 1);
      });
    }

    async initBackend() {
      if (!this.context) this.context = new AudioContext();

      try {
        await this.context.audioWorklet.addModule(chrome.runtime.getURL(WORKLET_PATH));
        this.backend = 'worklet';
        return true;
      } catch (error) {
        console.info('[Vineyy] AudioWorklet blocked on this page, using fallback.', error?.message || error);
      }

      try {
        ({ PitchShifterCore: this.PitchShifterCore } = await import(chrome.runtime.getURL(CORE_PATH)));
        this.backend = 'script';
        return true;
      } catch (error) {
        console.warn('[Vineyy] Independent pitch is unavailable on this page.', error);
        this.failed = true;
        return false;
      }
    }

    async prepare() {
      if (this.failed) return false;
      if (!this.backendReady) this.backendReady = this.initBackend();
      if (!(await this.backendReady)) return false;

      if (this.context.state !== 'running') {
        await Promise.race([this.context.resume().catch(() => {}), delay(150)]);
      }
      if (this.context.state !== 'running') {
        // Autoplay policy: wait for the first user gesture, then retry.
        this.armUnlock();
        return false;
      }
      return true;
    }

    createNode() {
      if (this.backend === 'worklet') {
        const node = new AudioWorkletNode(this.context, PROCESSOR_NAME);
        const param = node.parameters.get('ratio');
        return { input: node, output: node, setRatio: (r) => { param.value = r; } };
      }

      const core = new this.PitchShifterCore(this.context.sampleRate);
      const node = this.context.createScriptProcessor(4096, 2, 2);
      let ratio = 1;
      node.onaudioprocess = (event) => {
        const { inputBuffer, outputBuffer } = event;
        const inputs = [];
        const outputs = [];
        for (let ch = 0; ch < outputBuffer.numberOfChannels; ch++) {
          inputs.push(inputBuffer.getChannelData(ch));
          outputs.push(outputBuffer.getChannelData(ch));
        }
        core.process(inputs, outputs, ratio);
      };
      return { input: node, output: node, setRatio: (r) => { ratio = r; } };
    }

    attach(media) {
      if (this.pending.has(media)) return this.pending.get(media);

      const task = (async () => {
        if (!this.canRoute(media) || !(await this.prepare())) return null;
        if (!this.canRoute(media)) return null; // DRM keys can be attached while we were waiting
        try {
          const source = this.context.createMediaElementSource(media);
          const node = this.createNode();
          source.connect(node.input);
          node.output.connect(this.context.destination);
          this.nodes.set(media, node);
          return node;
        } catch (error) {
          console.warn('[Vineyy] Could not route media element:', error);
          return null;
        }
      })().finally(() => this.pending.delete(media));

      this.pending.set(media, task);
      return task;
    }

    /** True when independent pitch is possible for this element. */
    canRoute(media) {
      if (this.nodes.has(media)) return true;
      return !this.failed && this.isSafeToRoute(media);
    }

    isRouted(media) {
      return this.nodes.has(media);
    }

    /**
     * Web Audio would silence DRM streams (e.g. Spotify) and cross-origin
     * media without CORS, so those are left to the native path.
     */
    isSafeToRoute(media) {
      if (media.mediaKeys || DRM_HOSTS.test(location.hostname)) return false; // EME / DRM
      if (media.srcObject) return true; // MediaStream
      const src = media.currentSrc;
      if (!src) return false; // not loaded yet – retried on loadedmetadata
      if (src.startsWith('blob:') || src.startsWith('data:')) return true;
      try {
        return new URL(src, location.href).origin === location.origin || media.crossOrigin !== null;
      } catch {
        return false;
      }
    }

    armUnlock() {
      if (this.unlockArmed) return;
      this.unlockArmed = true;

      const unlock = () => {
        UNLOCK_EVENTS.forEach((type) => window.removeEventListener(type, unlock, true));
        this.unlockArmed = false;
        this.context.resume().then(() => this.onUnlock()).catch(() => {});
      };
      UNLOCK_EVENTS.forEach((type) => window.addEventListener(type, unlock, true));
    }
  }

  root.VineyyPitchEngine = PitchEngine;
})(globalThis);
