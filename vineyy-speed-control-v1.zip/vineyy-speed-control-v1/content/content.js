/**
 * Content-script entry point. Runs in every frame at document_start,
 * asks the background for this tab's state (so a refresh keeps the speed),
 * and listens for updates from the popup.
 *
 * Re-injection (after an extension update/reload, or from the popup into a
 * tab that was open before installation) replaces the previous controller
 * instead of being ignored, because the previous one may be orphaned.
 */
(function () {
  'use strict';

  const { MSG } = VINEYY;

  const previous = globalThis.__vineyyController;
  previous?.destroy?.();

  const controller = new VineyyMediaController({ engine: previous?.engine });
  globalThis.__vineyyController = controller; // inspection hook (isolated world only, invisible to the page)
  controller.start();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (globalThis.__vineyyController !== controller) return; // superseded by a newer injection
    if (message?.type === MSG.APPLY_STATE) controller.setState(message.state);
    if (message?.type === MSG.PING) sendResponse({ ok: true });
  });

  chrome.runtime
    .sendMessage({ type: MSG.GET_TAB_STATE })
    .then((response) => {
      if (response?.ok) controller.setState(response.state);
    })
    .catch(() => {
      /* Extension was reloaded/updated while this page stayed open. */
    });
})();
