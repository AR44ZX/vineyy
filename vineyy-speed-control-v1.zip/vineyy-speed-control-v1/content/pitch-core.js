/**
 * Pitch shifter DSP core (ES module, shared by the AudioWorklet and the
 * ScriptProcessor fallback).
 *
 * Classic dual-tap "delay-line" shifter: two read heads sweep through a short
 * circular buffer, offset by half a window, and are cross-faded with a Hann
 * window (the two gains always sum to 1, so there is no amplitude pumping).
 *
 * `ratio` is the factor applied ON TOP of what the media element already does
 * natively. When ratio ≈ 1 the core is a zero-latency pass-through.
 */
export class PitchShifterCore {
  constructor(sampleRate) {
    this.sampleRate = sampleRate;
    this.windowSize = Math.round(sampleRate * 0.05); // 50 ms grains
    this.bufferSize = 1 << Math.ceil(Math.log2(this.windowSize * 2 + 4));
    this.mask = this.bufferSize - 1;
    this.buffers = [];
    this.writeIndex = 0;
    this.phase = 0;
    this.bypassMix = 1; // 1 = dry pass-through, 0 = fully shifted
    this.mixStep = 1 / (sampleRate * 0.02); // 20 ms cross-fade between modes
  }

  read(buffer, writeIndex, delay) {
    const pos = writeIndex - delay;
    const i0 = Math.floor(pos);
    const frac = pos - i0;
    const a = buffer[i0 & this.mask];
    const b = buffer[(i0 + 1) & this.mask];
    return a + (b - a) * frac;
  }

  /**
   * @param {Float32Array[]} inputs  one array per channel
   * @param {Float32Array[]} outputs one array per channel
   * @param {number} ratio extra pitch ratio (1 = untouched)
   */
  process(inputs, outputs, ratio) {
    const channels = Math.min(inputs.length, outputs.length);
    if (channels === 0) return;
    while (this.buffers.length < channels) this.buffers.push(new Float32Array(this.bufferSize));

    const target = Math.abs(ratio - 1) < 0.002 ? 1 : 0;
    const phaseStep = (1 - ratio) / this.windowSize;
    const frames = outputs[0].length;
    const W = this.windowSize;

    let phase = this.phase;
    let mix = this.bypassMix;
    let wi = this.writeIndex;

    for (let i = 0; i < frames; i++) {
      if (mix < target) mix = Math.min(target, mix + this.mixStep);
      else if (mix > target) mix = Math.max(target, mix - this.mixStep);

      const p1 = phase;
      const p2 = phase >= 0.5 ? phase - 0.5 : phase + 0.5;
      const g1 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p1);
      const g2 = 0.5 - 0.5 * Math.cos(2 * Math.PI * p2);

      for (let ch = 0; ch < channels; ch++) {
        const buffer = this.buffers[ch];
        const x = inputs[ch][i];
        buffer[wi] = x;
        let y = x;
        if (mix < 1) {
          const wet = this.read(buffer, wi, p1 * W) * g1 + this.read(buffer, wi, p2 * W) * g2;
          y = mix * x + (1 - mix) * wet;
        }
        outputs[ch][i] = y;
      }

      wi = (wi + 1) & this.mask;
      phase += phaseStep;
      if (phase >= 1) phase -= 1;
      else if (phase < 0) phase += 1;
    }

    this.phase = phase;
    this.bypassMix = mix;
    this.writeIndex = wi;
  }
}
