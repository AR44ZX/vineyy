# Chrome Web Store – listing material

## Name
Vineyy - Speed Control

## Short description (max 132 chars)
Control video and audio speed and pitch (0.25x–2x) on any site. Built for YouTube, YouTube Music and Spotify.

## Detailed description
Vineyy lets you slow down or speed up any HTML5 video or audio and change its pitch – with a clean, dark, minimal popup.

• Speed and pitch from 0.25x to 2x
• "Link Speed & Pitch" switch: pitch follows speed like a tape/vinyl, with no robotic artefacts
• Unlink to set pitch independently of speed
• Reset buttons, exact value input, and 3 custom presets (hold or right-click a preset to save the current speed)
• Settings are kept per tab and survive page refreshes; new tabs start at 1x
• Knows when a page has no audio or video and says "No media" – otherwise it stays out of the way
• Designed for YouTube, YouTube Music and Spotify, works on any site with HTML5 media

Note: on DRM-protected streams (e.g. Spotify) the browser does not allow fully independent pitch. There, pitch either follows speed or stays at 1x, and the popup tells you.

Vineyy is an independent extension and is not affiliated with or endorsed by YouTube, Google or Spotify.

## Category
Productivity (alternative: Entertainment)

## Single purpose
Change the playback speed and pitch of audio and video on web pages.

## Permission justifications
- **storage** – saves the per-tab speed/pitch (session storage) and the user's 3 presets (sync storage).
- **scripting + host permission (<all_urls>)** – lets the extension attach to audio/video tabs that were already open when it was installed or updated, so the user does not have to refresh them.
- **Content script on all URLs (<all_urls>)** – the extension must find and control HTML5 <video>/<audio> elements on any site the user watches media on. It reads no page text, forms or personal data.
- No remote code is used. All code is bundled in the package.

## Privacy policy (publish this text at a public URL)
Vineyy - Speed Control does not collect, store on any server, sell or share personal data. It has no analytics, tracking or remote servers. Speed/pitch settings stay in your browser (chrome.storage.session for the current tab, chrome.storage.sync for your 3 presets, which Chrome may sync across your own devices). The only external link is a "Buy me a coffee" link that opens when you click it. Contact: (add your e-mail).

## Before you submit
1. Register a developer account (one-time USD 5 fee): https://chrome.google.com/webstore/devconsole
2. Add Inter (fonts/InterVariable.woff2 + OFL.txt) – or leave it out; the popup falls back to the system font.
3. Upload vineyy-speed-control.zip (manifest.json is already at the zip root). If you add the font, re-zip the folder contents so manifest.json stays at the root.
4. Prepare: 128x128 icon (included), at least one screenshot 1280x800 or 640x400, small promo tile 440x280.
5. Fill in the "Privacy practices" tab (single purpose, permissions above, no data collected) and the privacy-policy URL.
Because of the all-sites content script, expect a longer review.
